import pandas as pd
import clustering
import classification

data_file = 'heart_data_processed.csv'
heart_data = pd.read_csv(data_file)

clusters = clustering.get_clusters(heart_data)

for i in range(len(clusters)):
    X_train, X_test, y_train, y_test = classification.get_heart_train_test(clusters[i])

    log_model = classification.get_lr_classifier(X_train, y_train)
    nb_model = classification.get_nb_classifier(X_train, y_train)

    log_predictions = classification.get_predictions(log_model, X_test)
    nb_predictions = classification.get_predictions(nb_model, X_test)

    print('\n\n')
    print('Performance results for cluster i=',i)
    print('\nLogistic Regression results:')
    classification.print_performance_results(y_test, log_predictions)
    print('\nNaive Bayes results:')
    classification.print_performance_results(y_test, nb_predictions)
    print()