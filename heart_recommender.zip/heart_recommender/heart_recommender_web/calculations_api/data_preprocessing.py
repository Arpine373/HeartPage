import pandas as pd

heart_data = pd.read_csv('heart_data.csv')

print('Heart Data size: \n', heart_data.shape)
print('Heart Data head: \n', heart_data.head())
print('Heart Data columns: ', heart_data.columns)
print('Heart Data tail: \n', heart_data.tail(3))

print('Heart Data info: \n', heart_data.info())
print('Heart Data descriptive statistics: \n', heart_data.describe())

print('Number of Missing Values: ', heart_data.isna().sum())

import matplotlib.pyplot as plt

#correlation matrix
plt.matshow(heart_data.corr())
plt.xticks(range(heart_data.shape[1]), heart_data.columns, fontsize=14, rotation=90)
plt.yticks(range(heart_data.shape[1]), heart_data.columns, fontsize=14)
cb = plt.colorbar()
cb.ax.tick_params(labelsize=14)
plt.title('Կորելացիայի մատրից', y=-0.2)
plt.show()
#Result: correlation between target and other features is low, they are independant

#histograms
heart_data.hist()
plt.title('Հիստոգրամ')
plt.show()
#histogram shows that each feature has different value range so there is need for scaling
#Also histogram shows that some features have categorical values and we should handle it

#samples distribution
plt.bar(heart_data['target'].unique(), heart_data['target'].value_counts(), color = ['red', 'green']) 
plt.xticks([0, 1]) 
plt.xlabel('Կլասեր') 
plt.ylabel('Քանակ') 
plt.title('Ամեն կլասսի քանակ')
plt.show()
#Result data is equally distributed

#dummy coding
#processing categorical data for input
heart_data = pd.get_dummies(heart_data, columns = ['slope', 'ca', 'sex', 'thal', 'cp', 'fbs', 'restecg', 'exang'])

#scaling
from sklearn.preprocessing import StandardScaler
standardScaler = StandardScaler()
columns_to_scale = ['age', 'trestbps', 'chol', 'thalach', 'oldpeak']
heart_data[columns_to_scale] = standardScaler.fit_transform(heart_data[columns_to_scale])

#save to csv
#heart_data.to_csv('heart_data_processed.csv', sep=',', encoding='utf-8', index=False)