#Elbow method for detecting optimal number of clusters
import pandas as pd
from sklearn.cluster import KMeans
import numpy as np

heart_data = pd.read_csv('heart_processed.csv')
X = heart_data.drop('target', axis=1)

ks = list(range(1,11))
inertias = []

for clusters_number in ks:
    model = KMeans(n_clusters= clusters_number)
    model.fit(X)
    inertias.append(model.inertia_)

import matplotlib.pyplot as plt
plt.plot(ks, inertias)
plt.xlabel('Number of clusters')
plt.ylabel('Inertia')
plt.title('Inertia for clusters number from 1 to 10')
plt.show()