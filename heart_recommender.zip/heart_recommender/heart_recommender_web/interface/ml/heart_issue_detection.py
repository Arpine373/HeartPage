import pandas as pd

from . import clustering
from . import classification

from django.contrib.staticfiles.storage import staticfiles_storage

def detect_heart_issue(patient_values):
    # read preprocessed data
    #print(staticfiles_storage.url('data/heart_data_processed_le.csv'))
    data_file = './interface/static/data/heart_data_processed_le.csv'
    heart_data = pd.read_csv(data_file)

    # X & y
    X = heart_data.drop('target', axis=1)
    y = heart_data['target']

    # K-Means model generation & training
    kmeans_model = clustering.get_model(X)

    # Add cluster_id to each patient & scale
    X = clustering.get_data_with_trained_cluster_ids(X, kmeans_model)

    from sklearn.preprocessing import LabelEncoder
    label_encoder = LabelEncoder()
    X['cluster_id'] = label_encoder.fit_transform(X['cluster_id'])

    # 
    from sklearn.model_selection import train_test_split
    def get_heart_train_test(heart_data):
        X = heart_data.drop('target', axis=1)  # delete target
        y = heart_data['target']
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=101, stratify=y)
        return (X_train, X_test, y_train, y_test)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=101, stratify=y)
    #
    
    # Create Naive-Bayes classifier
    nb_model = classification.get_nb_classifier(X_train, y_train)

    patient_cluster_id = clustering.get_predicted_cluster_id(patient_values,kmeans_model)
    patient_values['cluster_id'] = patient_cluster_id
    print('patient_values: ', patient_values)

    nb_prediction = classification.get_predictions(nb_model, patient_values)
    print('nb_prediction: ', nb_prediction)

    return nb_prediction