import pandas as pd
from sklearn.cluster import KMeans
import numpy as np

def get_clusters(data, clusters_number = 4):
    model = KMeans(n_clusters= clusters_number)
    model.fit(data)
    #print(model.labels_)
    clusters = model.predict(data)
    #print(clusters)
    
    cluster_map = pd.DataFrame()
    cluster_map['data_id'] = data.index.values
    cluster_map['cluster_id'] = clusters # model.labels_

    def get_cluster_indexes(cluster_id):
        cluster_map_subset = cluster_map[cluster_map.cluster_id == cluster_id]
        return np.array(cluster_map_subset['data_id'])

    clusters_rows_ids = list(map(get_cluster_indexes, set(clusters)))
    clusters_dfs = list(map(lambda i: data.iloc[i], clusters_rows_ids))
    return clusters_dfs

def get_model(data, clusters_number = 4):
    model = KMeans(n_clusters= clusters_number, random_state=42)
    model.fit(data)
    return model

def get_data_with_trained_cluster_ids(data, model):
    data['cluster_id'] = model.labels_
    return data

def get_predicted_cluster_id(data, model):
    return list(model.predict(data))[0]