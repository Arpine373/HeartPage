from django.shortcuts import render

def heart_anatomy(request):
    return render(request, 'interface/heart_anatomy.html', {})

def about(request):
    return render(request, 'interface/about.html', {})

def heart_care_info(request):
    return render(request, 'interface/heart_care_info.html', {})

def heart_standard_checker(request):
    return render(request, 'interface/heart_standard_checker.html', {})

def heart_active_checker(request):
    return render(request, 'interface/heart_active_checker.html', {})

def heart_complex_checker(request):
    return render(request, 'interface/heart_complex_checker.html', {})

from django.views.decorators.csrf import csrf_exempt
import json
from django.http import HttpResponse
from django.http import JsonResponse

from .ml.heart_issue_detection import detect_heart_issue

import pandas as pd

@csrf_exempt
def check_heart_complexly(request):
    response = ''
    status_code = 200

    if request.method == 'POST':
        # get patient values from POST request and save to dataframe
        inputDataJson = json.loads(request.body)
        print("Json received: ", str(inputDataJson))

        print("Person age: ", inputDataJson['age'])

        patient_values = pd.DataFrame(columns=['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg', 'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal'])

        patient_values.loc[0] = [int(inputDataJson['age']), int(inputDataJson['sex']), 
                                    int(inputDataJson['cp']), int(inputDataJson['trestbps']),
                                    int(inputDataJson['chol']), int(inputDataJson['fbs']), 
                                    int(inputDataJson['restecg']), int(inputDataJson['thalach']),
                                    int(inputDataJson['exang']), int(inputDataJson['oldpeak']),
                                    int(inputDataJson['slope']), int(inputDataJson['ca']),
                                    int(inputDataJson['thal'])]

        #patient_values.columns = [['A','B','C']]

        print("Patient values dataframe: \n", patient_values.head())

        '''# convert categorical patient values
        categorical_columns = ['slope', 'ca', 'sex', 'thal', 'cp', 'fbs', 'restecg', 'exang']

        from sklearn.preprocessing import LabelEncoder
        label_encoder = LabelEncoder()
        patient_values[categorical_columns] = patient_values[categorical_columns].apply(label_encoder.fit_transform)

        print("Patient values processed categorical_columns: \n", patient_values[categorical_columns].head())

        # scale patient values
        from sklearn.preprocessing import StandardScaler
        standardScaler = StandardScaler()
        columns_to_scale = ['age', 'trestbps', 'chol', 'thalach', 'oldpeak']
        patient_values[columns_to_scale] = standardScaler.fit_transform(patient_values[columns_to_scale])

        print("Patient values scaled columns: \n", patient_values[columns_to_scale].head())

        #print("Patient values processed dataframe: \n", patient_values.head())'''

        response = detect_heart_issue(patient_values).item()
        print('response: ', response)
        
    #return JsonResponse(response, safe=False, status=status_code)
    return HttpResponse(response)