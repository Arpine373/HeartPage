from django.urls import path

from . import views

urlpatterns = [
    path('heart_anatomy', views.heart_anatomy, name='heart_anatomy'),
    path('', views.about, name='about'),
    path('heart_care_info', views.heart_care_info, name='heart_care_info'),
    path('heart_standard_checker', views.heart_standard_checker, name='heart_standard_checker'),
    path('heart_active_checker', views.heart_active_checker, name='heart_active_checker'),
    path('check_heart_complexly', views.check_heart_complexly, name='check_heart_complexly'),
    path('heart_complex_checker', views.heart_complex_checker, name='heart_complex_checker'),
]
