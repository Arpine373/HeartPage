function recommend_standard(){
    var cp = document.getElementsByName("arajin");
    var pressure = document.getElementById("Pressure");
    var maxheart = document.getElementById("MaxHeart");
    var time = document.getElementById("Time");
    var sport = document.getElementsByName("erkrord");
    var steps = document.getElementById("countStep");
    var health = document.getElementsByName("errord");
    console.log("Sport is: " + sport[0].value)
    console.log("Value of Cp: " + cp[0].checked)
    console.log("Value of health: " + health.value)


    console.log ( cp.value + ";" + pressure.value + maxheart.value + time.value + sport.value + steps.value + health.value);
    if(cp[1].checked == true || cp[2].checked == true || cp[3].checked == true){
        alert("Հարգելի՛ հիվանդ, հանդիպեք բժշկին")
    }
    else if(time.value <= 10){
        alert("Հարգելի՛ հիվանդ, հանդիպեք բժշկին");
    }
    else if( pressure.value >= 150 || maxheart.value >= 140 ){
        alert("Հարգելի՛ հիվանդ, հանդիպեք բժշկին");
    }
    else if(pressure.value <= 80 || maxheart.value <=50 ) {
        alert("Հարգելի՛ հիվանդ, հանդիպեք բժշկին");
    } 
    else if(steps.value <= 5000){
        alert("Հարգելի՛ հիվանդ, հանդիպեք բժշկին");
    }
    else if(sport[0].checked == true){
        alert("Հարգելի՛ հիվանդ, հանդիպեք բժշկին");
    }
    else if(health[0].checked == true){
        alert("Հարգելի՛ հիվանդ, հանդիպեք բժշկին");
    }
    else 
    {
        alert("Հարգելի՛ հիվանդ, դուք առողջ եք");
    }
};