    let age = document.getElementById("Age");
    let pressure = document.getElementById("Pressure");
    let maxheart = document.getElementById("MaxHeart");
    let btn = document.getElementById("myBtn");
    let closeButton = document.getElementsByClassName("close")[0];
    console.log (age.value + pressure.value + maxheart.value);
    let recommendationModal = document.getElementById("recommendationModal");
    // if( pressure.value >= 130 || maxheart.value >= 120 ){
    //     alert("Հարգելի՛ հիվանդ, հանդիպեք բժշկին");
    // }
    // else if(pressure.value <= 80 || pressure.value <=50 ) {
    //     alert("Հարգելի՛ հիվանդ, հանդիպեք բժշկին");
    // } 
    // else 
    // {
    //     alert("Հարգելի՛ հիվանդ, դուք առողջ եք");
    // }

    // When the user clicks on the button, open the modal
    btn.onclick = function() {
        let recommendationText = document.getElementById("recommendationText")
        if( pressure.value >= 130 || maxheart.value >= 120 ){ 
            recommendationText.innerHTML = "Հարգելի՛ հաճախորդ, հանդիպեք բժշկին"
        } else if(pressure.value <= 80 || pressure.value <=50 ){
            recommendationText.innerHTML = "Հարգելի՛ հաճախորդ, հանդիպեք բժշկին"
        } else{
            recommendationText.innerHTML = "Հարգելի՛ հաճախորդ, դուք առողջ եք"
        }
        recommendationModal.style.display = "block";
    };   
    // When the user clicks on <span> (x), close the modal
    closeButton.onclick = function() {
        recommendationModal.style.display = "none";
    };

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == recommendationModal) {
            recommendationModal.style.display = "none";
        }
    };   
