function checkComplexly(){
    var age = document.getElementById("age");
    var sex = document.getElementsByName("sex");
    var cp = document.getElementsByName("cp");
    var trestbps = document.getElementById("trestbps");

    var chol = document.getElementById("chol");
    var fbs = document.getElementById("fbs");
    var restecg = document.getElementsByName("restecg");
    var thalach = document.getElementById("thalach");

    var exang = document.getElementsByName("exang");
    var oldpeak = document.getElementsByName("oldpeak");
    var slope = document.getElementsByName("slope");
    var ca = document.getElementsByName("ca");

    var thal = document.getElementsByName("thal");

    console.log("Value of first exang: " + exang[0].value)
    console.log("Value of age: " + age.value)

    function getCheckedValue(radioButtons){
        checkedVal = null
        for(let i = 0; i < radioButtons.length; i++){
            if(radioButtons[i].checked == true){
                checkedVal = radioButtons[i].value
                break
            }
        }
        return checkedVal
    }
    console.log("exang value: " + getCheckedValue(exang))

    inputData = {}

    inputData["age"] = age.value
    inputData["sex"] = getCheckedValue(sex)
    inputData["cp"] = getCheckedValue(cp)
    inputData["trestbps"] = trestbps.value

    inputData["chol"] = chol.value
    inputData["fbs"] = fbs.value
    inputData["restecg"] = getCheckedValue(restecg)
    inputData["thalach"] = thalach.value

    inputData["exang"] = getCheckedValue(exang)
    inputData["oldpeak"] = getCheckedValue(oldpeak)
    inputData["slope"] = getCheckedValue(slope)
    inputData["ca"] = getCheckedValue(ca)

    inputData["thal"] = getCheckedValue(thal)

    inputDataJson = JSON.stringify(inputData, null, "")
    console.log("inputData json: " + inputDataJson)

    $.ajax({
        type: "POST",
        url: './check_heart_complexly',
        data: inputDataJson,
        success: checkHeartComplexlySuccessFunc,
        error: checkHeartComplexlyErrorFunc
    });

    function checkHeartComplexlySuccessFunc(data, textStatus, jQxhr) {
        if(data.includes("0")){
            alert("Այս հաճախորդը մեծագույն հավանականությամբ կարիք չունի սրտի ուշադիր ստուգման")
        } else{
            alert("Այս հաճախորդը մեծագույն հավանականությամբ կարիք ունի սրտի ուշադիր ստուգման")
        }
    }
    function checkHeartComplexlyErrorFunc(jqXhr, textStatus, errorThrown) {
        console.log(errorThrown);
    }
};