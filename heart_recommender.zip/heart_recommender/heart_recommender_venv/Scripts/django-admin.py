#!c:\users\levon\desktop\magister_work\heart_recommender\heart_recommender_venv\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
